<?php

$config = array(
	'Settings' => array(
		'WEBSITE' => 'http://localhost:8081/shopping-cart/',
		'SHOP_TITLE' => 'Shopping',
		'ADMIN_EMAIL' => 'testing.slinfy02.gmail.com',
		'DOMAIN' => '',
		'ANALYTICS' => '',
		'PAYPAL_API_USERNAME' => 'testing.slinfy02_api1.gmail.com',
		'PAYPAL_API_PASSWORD' => '1373275897',
		'PAYPAL_API_SIGNATURE' => 'AoNBG1CBIgLS5QaKlVpODjsaTncPABthzh5N-Nzz5tOodumbgF0TvVDq',
		'GOOGLE_CHECKOUT_URL' => '',
		'GOOGLE_CHECKOUT_MERCHANT_ID' => '',
		'GOOGLE_CHECKOUT_MERCHANT_KEY' => '',
		'AUTHORIZENET_ENABLED' => '1',
		'AUTHORIZENET_API_URL' => 'https://test.authorize.net/gateway/transact.dll',
		'AUTHORIZENET_API_LOGIN' => '42mcz2TDNTLf',
		'AUTHORIZENET_API_TRANSACTION_KEY' => '33d3nb5cFHX28vXD',
	)
);


