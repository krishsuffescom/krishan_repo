<?php

$config = array(
	'Settings' => array(
		'WEBSITE' => 'http://localhost/',
		'SHOP_TITLE' => 'CakePHP Shopping Cart',
		'ADMIN_EMAIL' => '',
		'DOMAIN' => '',
		'ANALYTICS' => '',
		'PAYPAL_API_USERNAME' => '',
		'PAYPAL_API_PASSWORD' => '',
		'PAYPAL_API_SIGNATURE' => '',
		'GOOGLE_CHECKOUT_URL' => '',
		'GOOGLE_CHECKOUT_MERCHANT_ID' => '',
		'GOOGLE_CHECKOUT_MERCHANT_KEY' => '',
		'AUTHORIZENET_ENABLED' => '1',
		'AUTHORIZENET_API_URL' => 'https://test.authorize.net/gateway/transact.dll',
		'AUTHORIZENET_API_LOGIN' => '',
		'AUTHORIZENET_API_TRANSACTION_KEY' => '',
	)
);


