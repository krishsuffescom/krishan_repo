<?php
if(isset($_SESSION[ADMIN_SESSION])){
	$flagl='lgin';
}
else{
	$flagl='nlgin';
}
?>