<div style="text-align:center; width:100%; padding:150px 0px 30px 0px; font-size:24px;">

Small Yellow Pages Admin Panel

</div>